.. module:: rake_nltk

This part of the documentation covers all the interfaces of rake_nltk.

Metric Object
-------------

.. autoclass:: Metric
    :undoc-members:
    :members:

Rake Object
-----------

.. autoclass:: Rake
    :members: