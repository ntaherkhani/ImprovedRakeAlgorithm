Release History
===============

v1.0.4
------
* Adding support for min and max words (inclusive) limits for ranked phrases.


v1.0.3
------
* Adding support for various metrics mentioned in the paper.


v1.0.2
------
* Minor fixes.


v1.0.1
------
* Adding support for other languages.


v1.0.0
------
* First release.